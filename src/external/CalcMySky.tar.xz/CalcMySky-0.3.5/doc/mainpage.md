# Table of contents

## [What is CalcMySky](whatis.html)
## [Installation](installation.html)
## [Generating atmosphere model](model-generation.html)
## [Previewing atmosphere model](model-preview.html)
## [Using in Stellarium](using-in-stellarium.html)
## [ShowMySky API](showmysky-api.html)
