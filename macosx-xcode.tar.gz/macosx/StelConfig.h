/*
 * StelConfig.h
 * Stellarium
 *
 * Created by Da Woon Jung on 3/16/05.
 * Copyright 2005 dwj. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */


/* OS X-specific replacement for existing setDirectories() */
#ifndef __OBJC__
extern "C" {
#endif

#define STELLARIUM_CONF_DIR	"Stellarium"
#define STELLARIUM_CONF_FILE    "config.ini"

extern bool setDirectories(const char **cdir, const char **data_root);

#ifndef __OBJC__
}
#endif
