#include <glm/glm.hpp>

int main()
{
    constexpr glm::vec4 v(2,3,5,9);
    (void)v;
}
